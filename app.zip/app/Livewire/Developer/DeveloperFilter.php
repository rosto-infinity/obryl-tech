<?php

namespace App\Livewire\Developer;

use Livewire\Component;

class DeveloperFilter extends Component
{
    public function render()
    {
        return view('livewire.developer.developer-filter');
    }
}
