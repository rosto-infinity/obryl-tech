<?php

namespace App\Livewire\Project;

use Livewire\Component;

class ProjectFilter extends Component
{
    public function render()
    {
        return view('livewire.project.project-filter');
    }
}
